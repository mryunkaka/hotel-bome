<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            // simpan DP atau CARD; default DP
            if (! Schema::hasColumn('reservations', 'deposit_type')) {
                $table->string('deposit_type', 20)
                    ->default('DP')
                    ->after('deposit');
            }
        });
    }

    public function down(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            if (Schema::hasColumn('reservations', 'deposit_type')) {
                $table->dropColumn('deposit_type');
            }
        });
    }
};
