<?php

namespace App\Filament\Resources\ReservationGuestCheckOuts\Pages;

use App\Filament\Resources\ReservationGuestCheckOuts\ReservationGuestCheckOutResource;
use Filament\Resources\Pages\CreateRecord;

class CreateReservationGuestCheckOut extends CreateRecord
{
    protected static string $resource = ReservationGuestCheckOutResource::class;
}
