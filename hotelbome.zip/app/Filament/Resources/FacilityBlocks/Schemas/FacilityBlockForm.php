<?php

namespace App\Filament\Resources\FacilityBlocks\Schemas;

use Filament\Schemas\Schema;

class FacilityBlockForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
