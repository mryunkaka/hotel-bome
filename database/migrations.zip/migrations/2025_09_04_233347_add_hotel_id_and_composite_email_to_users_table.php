<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Tambah kolom hotel_id (nullable untuk Super Admin global)
            $table->foreignId('hotel_id')->nullable()->after('id')->constrained()->nullOnDelete();

            // Drop unique index lama pada email (jika ada)
            // Nama index default biasanya "users_email_unique"
            try {
                $table->dropUnique('users_email_unique');
            } catch (\Throwable $e) {
                // abaikan jika index tidak ada
            }

            // Buat unique komposit: email + hotel_id
            $table->unique(['email', 'hotel_id'], 'users_email_hotel_unique');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Kembalikan ke unique email tunggal
            $table->dropUnique('users_email_hotel_unique');
            $table->unique('email', 'users_email_unique');

            // Hapus FK hotel
            $table->dropConstrainedForeignId('hotel_id');
        });
    }
};
