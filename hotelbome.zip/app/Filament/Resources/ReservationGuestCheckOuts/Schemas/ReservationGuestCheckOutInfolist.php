<?php

namespace App\Filament\Resources\ReservationGuestCheckOuts\Schemas;

use Filament\Schemas\Schema;

class ReservationGuestCheckOutInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
