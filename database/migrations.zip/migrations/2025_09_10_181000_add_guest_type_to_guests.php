<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('guests', function (Blueprint $table) {
            foreach (
                [
                    'salutation'    => 10,
                    'city'          => 100,
                    'nationality'   => 100,
                    'profession'    => 100,
                    'birth_place'   => 100,
                    'issued_place'  => 100,
                    'id_type'       => 20,
                ] as $col => $len
            ) {
                if (! Schema::hasColumn('guests', $col)) {
                    $table->string($col, $len)->nullable()->after('address');
                }
            }
            if (! Schema::hasColumn('guests', 'birth_date'))   $table->date('birth_date')->nullable();
            if (! Schema::hasColumn('guests', 'issued_date'))  $table->date('issued_date')->nullable();
        });
    }
    public function down(): void
    {
        Schema::table('guests', function (Blueprint $table) {
            $drop = ['salutation', 'city', 'nationality', 'profession', 'birth_place', 'birth_date', 'issued_place', 'issued_date', 'id_type'];
            foreach ($drop as $c) if (Schema::hasColumn('guests', $c)) $table->dropColumn($c);
        });
    }
};
