<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class GuestSeeder extends Seeder
{
    public function run(): void
    {
        $hotelIds = DB::table('hotels')->pluck('id');
        if ($hotelIds->isEmpty()) {
            $hotelIds = collect([1]);
        }

        $cols = Schema::getColumnListing('guests');

        $hasAddress = in_array('address', $cols, true);
        $hasIdCard  = in_array('id_card_no', $cols, true);
        $hasCity    = in_array('city', $cols, true);
        $hasCountry = in_array('country', $cols, true);
        $hasGender  = in_array('gender', $cols, true);

        $base = [
            ['name' => 'Andi Wijaya',  'email' => 'andi@example.com',  'phone' => '081234567890'],
            ['name' => 'Budi Santoso', 'email' => 'budi@example.com',  'phone' => '081298765432'],
            ['name' => 'Sari Lestari', 'email' => 'sari@example.com',  'phone' => '081377788899'],
            ['name' => 'Dewi Anggraini', 'email' => 'dewi@example.com', 'phone' => '081355566677'],
        ];

        foreach ($hotelIds as $hid) {
            foreach ($base as $row) {
                $payload = [
                    'hotel_id'   => $hid,
                    'name'       => $row['name'],
                    'email'      => Str::replace('@', "+h{$hid}@", $row['email']),
                    'phone'      => $row['phone'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ];

                if ($hasAddress) $payload['address'] = 'Jl. Contoh No. ' . random_int(1, 200);
                if ($hasIdCard)  $payload['id_card_no'] = (string) random_int(3200000000000000, 3299999999999999);
                if ($hasCity)    $payload['city'] = 'Banjarbaru';
                if ($hasCountry) $payload['country'] = 'ID';
                if ($hasGender)  $payload['gender'] = ['M', 'F'][array_rand(['M', 'F'])];

                DB::table('guests')->updateOrInsert(
                    ['hotel_id' => $hid, 'email' => $payload['email']],
                    $payload
                );
            }
        }
    }
}
