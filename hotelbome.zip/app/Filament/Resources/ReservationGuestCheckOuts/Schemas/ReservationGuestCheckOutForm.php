<?php

declare(strict_types=1);

namespace App\Filament\Resources\ReservationGuestCheckOuts\Schemas;

use App\Models\TaxSetting;
use Filament\Support\RawJs;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use Illuminate\Support\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\ReservationGuest;
use App\Support\ReservationMath;
use Illuminate\Support\Facades\Auth;
use Filament\Forms\Components\Select;
use Filament\Schemas\Components\Grid;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\ViewField;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Actions as SchemaActions;

final class ReservationGuestCheckOutForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('Guest Bill')
                ->collapsible()
                ->components([
                    ViewField::make('checkout_preview')
                        ->view('filament.forms.components.checkout-preview', [
                            'showTitle' => false,   // ⬅️ matikan judul di dalam view
                        ]),
                ])->columnSpanFull(),
            Section::make('Actions')
                ->schema([
                    Grid::make(12)->schema([
                        // Guest Folio (preview)
                        SchemaActions::make([
                            Action::make('folio_pdf')
                                ->label('Guest Folio')
                                ->icon('heroicon-o-clipboard-document-list')
                                ->url(fn(\App\Models\ReservationGuest $record) => route('reservation-guests.folio', $record))
                                ->openUrlInNewTab(),
                        ])->columns(1)->columnSpan(3),

                        // Room Post & Correction
                        SchemaActions::make([
                            Action::make('post_corr')
                                ->label('Room Post & Corr')
                                ->icon('heroicon-o-adjustments-horizontal')
                                ->form([
                                    TextInput::make('adjustment_rp')
                                        ->label('Adjustment (±Rp) → ditempel ke kolom Service')
                                        ->numeric()
                                        ->required(),
                                    Textarea::make('reason')->label('Reason')->rows(2),
                                ])
                                ->action(function (array $data, ReservationGuest $record): void {
                                    $record->service = (int)($record->service ?? 0) + (int)$data['adjustment_rp'];
                                    $record->save();

                                    \Filament\Notifications\Notification::make()
                                        ->title('Service adjusted.')
                                        ->success()
                                        ->send();
                                }),
                        ])->columns(1)->columnSpan(3),

                        // Print Bill (PDF)
                        SchemaActions::make([
                            Action::make('print_bill')
                                ->label('Print Bill')
                                ->icon('heroicon-o-printer')
                                // disabled sampai tamu sudah checkout
                                ->disabled(fn(ReservationGuest $record) => blank($record->actual_checkout))
                                ->tooltip(fn(ReservationGuest $record) => blank($record->actual_checkout)
                                    ? 'Hanya bisa dicetak setelah tamu checkout' : null)
                                ->action(function (ReservationGuest $record) {
                                    // hard guard kalau ada yang memaksa trigger
                                    if (blank($record->actual_checkout)) {
                                        \Filament\Notifications\Notification::make()
                                            ->title('Guest belum checkout.')
                                            ->danger()
                                            ->send();
                                        return;
                                    }

                                    $payload = self::buildBreakdown($record);
                                    $pdf = Pdf::loadView('prints.reservation_guests.bill', $payload);

                                    return response()->streamDownload(
                                        static fn() => print($pdf->output()),
                                        'Bill-' . $record->id . '.pdf'
                                    );
                                }),
                        ])->columns(1)->columnSpan(3),

                        // Payment & Check Out
                        SchemaActions::make([
                            Action::make('pay_and_checkout')
                                ->label('Payment & C/O')
                                ->icon('heroicon-o-credit-card')
                                ->form([
                                    TextInput::make('amount')->label('Amount (IDR)')->mask(RawJs::make('$money($input)'))->stripCharacters(',')->numeric()->required(),
                                    Select::make('method')->label('Method')->options([
                                        'CASH' => 'Cash',
                                        'CARD' => 'Card',
                                        'TRANSFER' => 'Transfer',
                                        'OTHER' => 'Other',
                                    ])->required(),
                                    Textarea::make('note')->label('Note')->rows(2),
                                ])
                                ->mutateFormDataUsing(function (array $data, ReservationGuest $record): array {
                                    $calc = self::buildBreakdown($record);
                                    $due  = max(0, (int)$calc['grand_total'] - (int)$calc['deposit']);
                                    $data['amount'] = $data['amount'] ?? $due;
                                    return $data;
                                })
                                ->action(function (array $data, ReservationGuest $record): void {
                                    \App\Models\Payment::create([
                                        'hotel_id'             => $record->hotel_id,
                                        'reservation_id'       => $record->reservation_id,
                                        'reservation_guest_id' => $record->id,
                                        'amount'               => (int) $data['amount'],
                                        'method'               => (string) $data['method'],
                                        'payment_date'         => now(),
                                        'note'                 => (string) ($data['note'] ?? ''),
                                        'created_by'           => Auth::id(),
                                    ]);

                                    $record->forceFill([
                                        'actual_checkout' => now(),
                                        'bill_closed_at'  => now(),
                                    ])->save();

                                    $res = $record->reservation;
                                    if ($res && ! $res->checkout_date) {
                                        $remaining = $res->reservationGuests()->whereNull('actual_checkout')->count();
                                        if ($remaining === 0) {
                                            $res->checkout_date = now();
                                            $res->save();
                                        }
                                    }

                                    \Filament\Notifications\Notification::make()
                                        ->title('Guest checked out & payment recorded.')
                                        ->success()
                                        ->send();
                                }),
                        ])->columns(1)->columnSpan(3),

                    ]),
                ])
                ->columnSpanFull(),
        ]);
    }


    /**
     * Hitung detail breakdown untuk modal folio & print
     */
    private static function buildBreakdown(ReservationGuest $rg): array
    {
        $start = $rg->actual_checkin ?? $rg->expected_checkin;
        $end   = $rg->actual_checkout ?? $rg->expected_checkout;

        $nights = ReservationMath::nights($start, $end);

        $taxLookup = TaxSetting::where('hotel_id', $rg->hotel_id)
            ->pluck('percent', 'id')->all();

        $baseRate   = (float) ($rg->room_rate ?? 0);
        $discPct    = (float) ($rg->discount_percent ?? 0);
        $serviceRp  = (float) ($rg->service ?? 0);
        $extraQty   = (int)   ($rg->extra_bed ?? 0);
        // Jika Anda punya konstanta harga extra bed, pakai di sini. Untuk sementara anggap 0 jika tidak ada.
        $EXTRA_BED_PRICE = defined('\App\Models\ReservationGuest::EXTRA_BED_PRICE')
            ? (int) \App\Models\ReservationGuest::EXTRA_BED_PRICE
            : 0;
        $extraTotal = $extraQty * $EXTRA_BED_PRICE;

        $late = ReservationMath::latePenalty($rg->expected_checkin, $rg->actual_checkin, $baseRate);
        $lateRp = (float) ($late['amount'] ?? 0);

        $taxPercent = (float) ($rg->tax?->percent ?? ($taxLookup[$rg->id_tax] ?? 0));

        $rateAfterDiscNight = max(0, $baseRate * (1 - $discPct / 100));
        $rateAfterDiscTotal = $rateAfterDiscNight * max(1, $nights);

        $subtotalBeforeTax = $rateAfterDiscTotal + $serviceRp + $extraTotal + $lateRp;

        $taxRp = (int) round($subtotalBeforeTax * ($taxPercent / 100));
        $grand = (int) round($subtotalBeforeTax + $taxRp);

        return [
            'rg'              => $rg,
            'nights'          => $nights,
            'rate_after_disc' => (int) round($rateAfterDiscTotal),
            'service'         => (int) $serviceRp,
            'extra_bed'       => (int) $extraTotal,
            'late_penalty'    => (int) $lateRp,
            'tax_percent'     => $taxPercent,
            'tax_rp'          => (int) $taxRp,
            'grand_total'     => (int) $grand,
            'deposit'         => (int) ($rg->reservation?->deposit ?? 0),

            // Metadata opsional untuk header print
            'arrive_at'       => $start ? Carbon::parse($start)->format('d/m/Y H:i') : '-',
            'depart_at'       => $end ? Carbon::parse($end)->format('d/m/Y H:i') : '-',
            'guest_name'      => $rg->guest?->name,
            'room_no'         => $rg->room?->room_no,
        ];
    }
}
