<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            // Kalau ada FK, lepaskan dulu lalu pasang lagi dengan nullOnDelete()
            if (Schema::hasColumn('reservations', 'room_id')) {
                try {
                    $table->dropForeign(['room_id']);
                } catch (\Throwable $e) {
                }
                $table->unsignedBigInteger('room_id')->nullable()->change();
                $table->foreign('room_id')->references('id')->on('rooms')->nullOnDelete();
            }

            if (Schema::hasColumn('reservations', 'guest_id')) {
                try {
                    $table->dropForeign(['guest_id']);
                } catch (\Throwable $e) {
                }
                $table->unsignedBigInteger('guest_id')->nullable()->change();
                $table->foreign('guest_id')->references('id')->on('guests')->nullOnDelete();
            }
        });
    }

    public function down(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            // Kembalikan seperti semula ( NOT NULL )
            if (Schema::hasColumn('reservations', 'room_id')) {
                try {
                    $table->dropForeign(['room_id']);
                } catch (\Throwable $e) {
                }
                $table->unsignedBigInteger('room_id')->nullable(false)->change();
            }
            if (Schema::hasColumn('reservations', 'guest_id')) {
                try {
                    $table->dropForeign(['guest_id']);
                } catch (\Throwable $e) {
                }
                $table->unsignedBigInteger('guest_id')->nullable(false)->change();
            }
        });
    }
};
