<?php

declare(strict_types=1);

namespace App\Filament\Resources\ReservationGuestCheckOuts\Schemas;

use App\Models\Bank;
use App\Models\Payment;
use App\Models\BankLedger;
use Filament\Support\RawJs;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use App\Models\AccountLedger;
use App\Models\ReservationGuest;
use App\Support\ReservationMath;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Select;
use Filament\Schemas\Components\Grid;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\ViewField;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Actions as SchemaActions;

final class ReservationGuestCheckOutForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('Guest Bill')
                ->collapsible()
                ->components([
                    ViewField::make('checkout_preview')
                        ->view('filament.forms.components.checkout-preview', [
                            'showTitle' => false,   // ⬅️ matikan judul di dalam view
                        ]),
                ])->columnSpanFull(),
            Section::make('Actions')
                ->schema([
                    Grid::make(15)->schema([

                        // ===================== Guest Folio =====================
                        SchemaActions::make([
                            Action::make('folio_pdf')
                                ->label('Guest Folio')
                                ->icon('heroicon-o-clipboard-document-list')
                                ->disabled(fn(\App\Models\ReservationGuest $record) => blank($record->actual_checkout))
                                ->tooltip(fn(\App\Models\ReservationGuest $record) => blank($record->actual_checkout)
                                    ? 'Hanya tersedia setelah semua tamu telah check out.' : null)
                                ->url(fn(\App\Models\ReservationGuest $record) => route('reservation-guests.folio', $record))
                                ->openUrlInNewTab()
                                ->color('info')        // UI: warna biru-informasi
                                ->button()             // UI: gaya tombol
                                ->outlined(),          // UI: outline biar beda aksen
                        ])->columns(1)->columnSpan(3)
                            ->alignment('center'),       // UI: posisikan tombol di tengah

                        // ===================== Room Post & Correction =====================
                        SchemaActions::make([
                            Action::make('post_corr')
                                ->label('P & C')
                                ->icon('heroicon-o-adjustments-horizontal')
                                ->disabled(function (\App\Models\ReservationGuest $record): bool {
                                    if (filled($record->actual_checkout)) {
                                        return true;
                                    }
                                    return \App\Models\Payment::where('reservation_guest_id', $record->id)->exists();
                                })
                                ->tooltip(function (\App\Models\ReservationGuest $record) {
                                    if (filled($record->actual_checkout)) {
                                        return 'Tamu sudah check out.';
                                    }
                                    if (\App\Models\Payment::where('reservation_guest_id', $record->id)->exists()) {
                                        return 'Payment already recorded — posting/correction is locked.';
                                    }
                                    return null;
                                })
                                ->schema([
                                    TextInput::make('adjustment_rp')
                                        ->label('Adjustment (±Rp) → ditempel ke kolom Charge')
                                        ->numeric()
                                        ->mask(\Filament\Support\RawJs::make('$money($input)'))
                                        ->stripCharacters(',')
                                        ->required(),
                                    \Filament\Forms\Components\Textarea::make('reason')->label('Reason')->rows(2),
                                ])
                                ->action(function (array $data, \App\Models\ReservationGuest $record): void {
                                    if (filled($record->actual_checkout)) {
                                        \Filament\Notifications\Notification::make()
                                            ->title('Guest sudah checkout — tidak bisa melakukan Room Post & Correction.')
                                            ->warning()
                                            ->send();
                                        return;
                                    }
                                    if (\App\Models\Payment::where('reservation_guest_id', $record->id)->exists()) {
                                        \Filament\Notifications\Notification::make()
                                            ->title('Payment untuk guest ini sudah ada — Room Post & Correction dikunci.')
                                            ->warning()
                                            ->send();
                                        return;
                                    }
                                    $record->charge = (int) ($record->charge ?? 0) + (int) $data['adjustment_rp'];
                                    $record->save();

                                    \Filament\Notifications\Notification::make()
                                        ->title('Charge adjusted.')
                                        ->success()
                                        ->send();
                                })
                                ->color('gray')   // UI: abu-abu agar beda dari tombol lain
                                ->button()
                                ->outlined(),
                        ])->columns(1)->columnSpan(3)
                            ->alignment('center'),

                        // ===================== Print Bill =====================
                        SchemaActions::make([
                            Action::make('print_bill')
                                ->label('Print Bill')
                                ->icon('heroicon-o-printer')
                                ->disabled(fn(\App\Models\ReservationGuest $record) => blank($record->actual_checkout))
                                ->tooltip(fn(\App\Models\ReservationGuest $record) => blank($record->actual_checkout)
                                    ? 'Hanya tersedia setelah semua tamu telah check out.' : null)
                                ->url(function (\App\Models\ReservationGuest $record) {
                                    $res = $record->reservation;
                                    // kalau ada guest lain yang SUDAH checkout, tampilkan sisa (remaining)
                                    $hasChecked = $res?->reservationGuests()
                                        ->whereNotNull('actual_checkout')
                                        ->where('id', '!=', $record->id)
                                        ->exists();

                                    $mode = $hasChecked ? 'remaining' : 'all';
                                    return route('reservation-guests.bill', $record) . '?mode=' . $mode;
                                })
                                ->openUrlInNewTab()
                                ->color('primary')
                                ->button(),
                        ])->columns(1)->columnSpan(3)
                            ->alignment('center'),

                        SchemaActions::make([
                            Action::make('split_bill')
                                ->label('Split Bill')
                                ->icon('heroicon-o-scissors')
                                ->color('warning')
                                ->button()
                                ->schema([
                                    // Tampilkan "Actual Amount" (porsi tamu ini) untuk referensi
                                    TextInput::make('actual_amount_view')
                                        ->label('Actual Amount (IDR)')
                                        ->disabled()
                                        ->dehydrated(false)
                                        ->mask(\Filament\Support\RawJs::make('$money($input)'))
                                        ->extraInputAttributes(['inputmode' => 'numeric']),

                                    Hidden::make('actual_amount'),

                                    // Opsional: Pay now?
                                    \Filament\Forms\Components\Toggle::make('record_payment_now')
                                        ->label('Record payment now (post to ledger)')
                                        ->inline(false),

                                    TextInput::make('amount')
                                        ->label('Amount Paid (IDR)')
                                        ->numeric()
                                        ->minValue(0)
                                        ->mask(\Filament\Support\RawJs::make('$money($input)'))
                                        ->stripCharacters(',')
                                        ->visible(fn(Get $get) => (bool) $get('record_payment_now'))
                                        ->required(fn(Get $get) => (bool) $get('record_payment_now')),

                                    Select::make('method')
                                        ->label('Method')
                                        ->options([
                                            'CASH'     => 'Cash',
                                            'CARD'     => 'Card',
                                            'TRANSFER' => 'Transfer',
                                            'OTHER'    => 'Other',
                                        ])
                                        ->visible(fn(Get $get) => (bool) $get('record_payment_now'))
                                        ->required(fn(Get $get) => (bool) $get('record_payment_now'))
                                        ->reactive(),

                                    Select::make('bank_id')
                                        ->label('Bank Account')
                                        ->options(function (\App\Models\ReservationGuest $record) {
                                            return \App\Models\Bank::query()
                                                ->where('hotel_id', $record->hotel_id)
                                                ->orderBy('name')->pluck('name', 'id');
                                        })
                                        ->searchable()->preload()->native(false)
                                        ->visible(fn(Get $get) => (bool) $get('record_payment_now') && in_array($get('method'), ['CARD', 'TRANSFER'], true))
                                        ->required(fn(Get $get) => (bool) $get('record_payment_now') && in_array($get('method'), ['CARD', 'TRANSFER'], true))
                                        ->helperText('Wajib untuk CARD/TRANSFER.'),

                                    Textarea::make('note')->label('Note')->rows(2)
                                        ->visible(fn(Get $get) => (bool) $get('record_payment_now')),
                                ])
                                ->mutateDataUsing(function (array $data, \App\Models\ReservationGuest $record) {
                                    // Hitung porsi SPLIT (SUBTOTAL + pajak per orang) — konsisten dg tampilan
                                    $calc        = \App\Filament\Resources\ReservationGuestCheckOuts\Schemas\ReservationGuestCheckOutForm::buildBreakdown($record);
                                    $grand       = (int) ($calc['grand_total'] ?? $calc['grand'] ?? 0);
                                    $taxTotalRp  = (int) ($calc['tax_rp']      ?? 0);
                                    $taxPct      = (float)($calc['tax_percent'] ?? 0.0);
                                    $subTotal    = max(0, $grand - $taxTotalRp);
                                    $res         = $record->reservation;
                                    $participants = max(1, (int) $res?->reservationGuests()->count());

                                    $taxPerPersonRp = (int) floor(($subTotal * ($taxPct / 100)) / $participants);
                                    $remainder      = (int) round(($subTotal * ($taxPct / 100))) - ($taxPerPersonRp * $participants);
                                    if ($remainder > 0 && $res) {
                                        $maxId = (int) $res->reservationGuests()->max('id');
                                        if ((int) $record->id === $maxId) {
                                            $taxPerPersonRp += $remainder;
                                        }
                                    }
                                    $actualAmount = (int) $subTotal + $taxPerPersonRp;

                                    // Set default untuk modal
                                    $data['actual_amount']      = $actualAmount;
                                    $data['actual_amount_view'] = $actualAmount;
                                    if (!isset($data['amount']) || $data['amount'] === null || $data['amount'] === '') {
                                        $data['amount'] = $actualAmount;
                                    }
                                    return $data;
                                })
                                ->action(function (array $data, \App\Models\ReservationGuest $record, \Livewire\Component $livewire) {
                                    // Guard: bila RG sudah ada pembayaran real, jangan SPLIT lagi
                                    $hasRealPayment = \App\Models\Payment::query()
                                        ->where('reservation_guest_id', $record->id)
                                        ->where(function ($q) {
                                            $q->whereNull('method')
                                                ->orWhereNotIn('method', ['SPLIT', 'DEPOSIT', 'DEPOSIT_CARD', 'DEPOSIT CASH', 'DEPOSIT-CARD', 'DEPOSITCARD']);
                                        })->exists();
                                    if ($hasRealPayment) {
                                        \Filament\Notifications\Notification::make()->title('Guest ini sudah memiliki pembayaran.')->warning()->send();
                                        return;
                                    }

                                    // Tandai RG checkout (jangan sentuh reservation->checkout_date di sini)
                                    if (blank($record->actual_checkout)) {
                                        $record->forceFill(['actual_checkout' => now()])->save();
                                    }

                                    $res = $record->reservation;
                                    if (! $res) {
                                        \Filament\Notifications\Notification::make()->title('Reservation tidak ditemukan.')->warning()->send();
                                        return;
                                    }

                                    $actualAmount      = (int) ($data['actual_amount'] ?? 0);
                                    $recordPaymentNow  = (bool) ($data['record_payment_now'] ?? false);

                                    if (! $recordPaymentNow) {
                                        // === MODE 1: SPLIT ONLY (marker non-kas, tanpa ledger) ===
                                        \App\Models\Payment::updateOrCreate(
                                            [
                                                'reservation_guest_id' => $record->id,
                                                'method'               => 'SPLIT',
                                            ],
                                            [
                                                'hotel_id'       => (int) $res->hotel_id,
                                                'reservation_id' => (int) $res->id,
                                                'amount'         => $actualAmount,
                                                'actual_amount'  => $actualAmount,
                                                'payment_date'   => now(),
                                                'notes'          => 'Auto entry (Split Bill)',
                                                'created_by'     => \Illuminate\Support\Facades\Auth::id(),
                                            ]
                                        );

                                        // Buka bill mode=single
                                        $url = route('reservation-guests.bill', $record) . '?mode=single';
                                        $livewire->js("window.open('{$url}', '_blank', 'noopener,noreferrer')");
                                        return;
                                    }

                                    // === MODE 2: SPLIT + PAY NOW (kas/edc/transfer) ===
                                    $pay  = (int) ($data['amount'] ?? 0);
                                    if ($pay < $actualAmount) {
                                        \Filament\Notifications\Notification::make()
                                            ->title('Amount kurang dari porsi tagihan (split).')
                                            ->body('Jumlah yang dibayar harus ≥ Actual Amount (porsi tamu ini).')
                                            ->danger()->send();
                                        return;
                                    }

                                    $methodForm = strtoupper((string) ($data['method'] ?? 'CASH'));
                                    $bankId     = isset($data['bank_id']) ? (int) $data['bank_id'] : null;

                                    if (in_array($methodForm, ['CARD', 'TRANSFER'], true)) {
                                        if (empty($bankId)) {
                                            \Filament\Notifications\Notification::make()->title('Bank belum dipilih.')->warning()->send();
                                            return;
                                        }
                                        $isSameHotel = \App\Models\Bank::whereKey($bankId)
                                            ->where('hotel_id', $record->hotel_id)->exists();
                                        if (! $isSameHotel) {
                                            \Filament\Notifications\Notification::make()->title('Bank tidak valid untuk hotel ini.')->danger()->send();
                                            return;
                                        }
                                    }

                                    $methodForLedger = match ($methodForm) {
                                        'CASH'     => 'cash',
                                        'CARD'     => 'edc',
                                        'TRANSFER' => 'transfer',
                                        default    => 'other',
                                    };

                                    DB::transaction(function () use ($data, $record, $res, $methodForLedger, $bankId, $methodForm, $actualAmount) {
                                        // 1) Simpan Payment REAL (bukan SPLIT)
                                        $payment = \App\Models\Payment::create([
                                            'hotel_id'             => (int) $res->hotel_id,
                                            'reservation_id'       => (int) $res->id,
                                            'reservation_guest_id' => (int) $record->id,
                                            'bank_id'              => $bankId,
                                            'amount'               => (int) $data['amount'],       // uang diterima kasir
                                            'actual_amount'        => (int) $actualAmount,         // porsi due saat ini
                                            'method'               => (string) $methodForm,        // CASH/CARD/TRANSFER/OTHER
                                            'payment_date'         => now(),
                                            'notes'                => (string) ($data['note'] ?? 'Split Bill (pay now)'),
                                            'created_by'           => \Illuminate\Support\Facades\Auth::id(),
                                        ]);

                                        // 2) Post ke Ledger (net + change)
                                        $entryDate = now()->toDateString();
                                        $description = 'Split Checkout #' . ($res->code ?? $res->id) . '/RG#' . $record->id;

                                        $paid   = (int) ($data['amount'] ?? 0);
                                        $must   = (int) $actualAmount;
                                        $change = max(0, $paid - $must);
                                        $amountInNet = min($paid, $must);

                                        if ($methodForLedger === 'cash' || empty($bankId)) {
                                            \App\Models\AccountLedger::create([
                                                'hotel_id'        => (int) $res->hotel_id,
                                                'ledger_type'     => 'room',
                                                'reference_table' => 'payments',
                                                'reference_id'    => (int) $payment->id,
                                                'account_code'    => 'CASH_ON_HAND',
                                                'method'          => 'cash',
                                                'debit'           => $amountInNet,
                                                'credit'          => 0,
                                                'date'            => $entryDate,
                                                'description'     => $description . ' (receipt)',
                                                'is_posted'       => true,
                                                'posted_at'       => now(),
                                                'posted_by'       => \Illuminate\Support\Facades\Auth::id(),
                                            ]);
                                            if ($change > 0) {
                                                \App\Models\AccountLedger::create([
                                                    'hotel_id'        => (int) $res->hotel_id,
                                                    'ledger_type'     => 'room',
                                                    'reference_table' => 'payments',
                                                    'reference_id'    => (int) $payment->id,
                                                    'account_code'    => 'CASH_ON_HAND',
                                                    'method'          => 'cash',
                                                    'debit'           => 0,
                                                    'credit'          => $change,
                                                    'date'            => $entryDate,
                                                    'description'     => $description . ' (change returned)',
                                                    'is_posted'       => true,
                                                    'posted_at'       => now(),
                                                    'posted_by'       => \Illuminate\Support\Facades\Auth::id(),
                                                ]);
                                            }
                                        } else {
                                            \App\Models\BankLedger::create([
                                                'hotel_id'        => (int) $res->hotel_id,
                                                'bank_id'         => (int) $bankId,
                                                'deposit'         => $amountInNet,
                                                'withdraw'        => 0,
                                                'date'            => $entryDate,
                                                'description'     => $description . ' (receipt)',
                                                'method'          => $methodForLedger,
                                                'ledger_type'     => 'room',
                                                'reference_table' => 'payments',
                                                'reference_id'    => (int) $payment->id,
                                                'is_posted'       => true,
                                                'posted_at'       => now(),
                                                'posted_by'       => \Illuminate\Support\Facades\Auth::id(),
                                            ]);
                                            if ($change > 0) {
                                                \App\Models\BankLedger::create([
                                                    'hotel_id'        => (int) $res->hotel_id,
                                                    'bank_id'         => (int) $bankId,
                                                    'deposit'         => 0,
                                                    'withdraw'        => $change,
                                                    'date'            => $entryDate,
                                                    'description'     => $description . ' (refund/change)',
                                                    'method'          => $methodForLedger,
                                                    'ledger_type'     => 'room',
                                                    'reference_table' => 'payments',
                                                    'reference_id'    => (int) $payment->id,
                                                    'is_posted'       => true,
                                                    'posted_at'       => now(),
                                                    'posted_by'       => \Illuminate\Support\Facades\Auth::id(),
                                                ]);
                                            }
                                        }

                                        // 3) Tandai RG ini closed & mark service (minibar/laundry/dll) milik RG ini sebagai PAID
                                        $now = now();
                                        $record->forceFill([
                                            'bill_closed_at' => $now,
                                        ])->save();

                                        // Minibar
                                        $mr = \App\Models\MinibarReceipt::query()
                                            ->where('reservation_guest_id', $record->id);
                                        $update = [];
                                        if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'is_paid'))  $update['is_paid'] = true;
                                        if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'status'))   $update['status'] = 'PAID';
                                        if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'paid_at'))  $update['paid_at'] = $now;
                                        if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'paid_by'))  $update['paid_by'] = \Illuminate\Support\Facades\Auth::id();
                                        if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'updated_by')) $update['updated_by'] = \Illuminate\Support\Facades\Auth::id();
                                        if (!empty($update)) $mr->update($update);

                                        // (opsional) Laundry/Massage model jika ada…
                                        // foreach ([\App\Models\LaundryReceipt::class, \App\Models\MassageReceipt::class] as $serviceModel) {
                                        //     if (class_exists($serviceModel)) {
                                        //         $serviceModel::query()
                                        //             ->where('reservation_guest_id', $record->id)
                                        //             ->update(array_merge($update, []));
                                        //     }
                                        // }

                                        // Ubah status kamar RG ini jadi Vacant-Dirty
                                        if ($record->room_id) {
                                            \App\Models\Room::whereKey($record->room_id)->update([
                                                'status'            => \App\Models\Room::ST_VD,
                                                'status_changed_at' => $now,
                                            ]);
                                        }

                                        \Filament\Notifications\Notification::make()
                                            ->title('Split payment posted.')
                                            ->success()->send();
                                    });

                                    // Cetak bill “single” untuk RG ini
                                    $url = route('reservation-guests.bill', $record) . '?mode=single';
                                    $livewire->js("window.open('{$url}', '_blank', 'noopener,noreferrer')");
                                })
                                ->tooltip('Pisahkan tagihan untuk tamu ini'),
                        ])->columns(1)->columnSpan(3)->alignment('center'),

                        // ===================== Payment & Check Out =====================
                        SchemaActions::make([
                            Action::make('pay_and_checkout_adv')
                                ->label('C/O')
                                ->icon('heroicon-o-credit-card')
                                ->color('success')   // UI: hijau untuk aksi utama
                                ->button()
                                ->disabled(function (\App\Models\ReservationGuest $record): bool {
                                    if (filled($record->actual_checkout)) {
                                        return true;
                                    }
                                    return \App\Models\Payment::where('reservation_guest_id', $record->id)->exists();
                                })
                                ->schema([
                                    Hidden::make('reservation_guest_id')
                                        ->default(fn(\App\Models\ReservationGuest $record) => $record->id),

                                    // === Actual Amount: ambil LANGSUNG dari Amount to pay now (preview) ===
                                    TextInput::make('actual_amount_view')
                                        ->label('Actual Amount (IDR)')
                                        ->disabled()
                                        ->dehydrated(false)
                                        ->mask(RawJs::make('$money($input)'))
                                        ->extraInputAttributes(['inputmode' => 'numeric'])
                                        ->default(function (\App\Models\ReservationGuest $record): int {
                                            $calc = \App\Filament\Resources\ReservationGuestCheckOuts\Schemas\ReservationGuestCheckOutForm::buildBreakdown($record);
                                            return (int) ($calc['reservation_open_due'] ?? 0);   // == Amount to pay now
                                        }),

                                    Hidden::make('actual_amount')
                                        ->default(function (\App\Models\ReservationGuest $record): int {
                                            $calc = \App\Filament\Resources\ReservationGuestCheckOuts\Schemas\ReservationGuestCheckOutForm::buildBreakdown($record);
                                            return (int) ($calc['reservation_open_due'] ?? 0);   // == Amount to pay now
                                        }),

                                    // Default-kan amount ke actual_amount biar auto terisi
                                    TextInput::make('amount')
                                        ->label('Amount (IDR)')
                                        ->numeric()
                                        ->minValue(0)
                                        ->mask(RawJs::make('$money($input)'))
                                        ->stripCharacters(',')
                                        ->required()
                                        ->default(function (\App\Models\ReservationGuest $record): int {
                                            $calc = \App\Filament\Resources\ReservationGuestCheckOuts\Schemas\ReservationGuestCheckOutForm::buildBreakdown($record);
                                            return (int) ($calc['reservation_open_due'] ?? 0);
                                        }),

                                    Select::make('method')
                                        ->label('Method')
                                        ->options([
                                            'CASH'     => 'Cash',
                                            'CARD'     => 'Card',
                                            'TRANSFER' => 'Transfer',
                                            'OTHER'    => 'Other',
                                        ])
                                        ->required()
                                        ->reactive(),

                                    Select::make('bank_id')
                                        ->label('Bank Account')
                                        ->options(
                                            fn(\App\Models\ReservationGuest $record) =>
                                            Bank::query()
                                                ->where('hotel_id', $record->hotel_id)
                                                ->orderBy('name')
                                                ->pluck('name', 'id')
                                        )
                                        ->searchable()
                                        ->preload()
                                        ->native(false)
                                        ->visible(fn(Get $get) => in_array($get('method'), ['CARD', 'TRANSFER'], true))
                                        ->required(fn(Get $get) => in_array($get('method'), ['CARD', 'TRANSFER'], true))
                                        ->helperText('Wajib diisi untuk CARD/TRANSFER.'),

                                    Textarea::make('note')->label('Note')->rows(2),
                                ])
                                ->mutateDataUsing(function (array $data, \App\Models\ReservationGuest $record) {
                                    // Safety fallback: kalau user hapus amount, pakai angka dari breakdown (Amount to pay now)
                                    if (!isset($data['amount']) || $data['amount'] === '' || $data['amount'] === null) {
                                        $calc = \App\Filament\Resources\ReservationGuestCheckOuts\Schemas\ReservationGuestCheckOutForm::buildBreakdown($record);
                                        $data['amount'] = (int) ($calc['reservation_open_due'] ?? 0);
                                    }

                                    // pastikan hidden actual_amount juga sinkron
                                    if (!isset($data['actual_amount'])) {
                                        $calc = \App\Filament\Resources\ReservationGuestCheckOuts\Schemas\ReservationGuestCheckOutForm::buildBreakdown($record);
                                        $data['actual_amount'] = (int) ($calc['reservation_open_due'] ?? 0);
                                    }

                                    $data['reservation_guest_id'] = (int) $record->id;
                                    return $data;
                                })
                                ->action(function (array $data, \App\Models\ReservationGuest $record, \Livewire\Component $livewire) {
                                    // Validasi: amount harus ≥ actual_amount
                                    $pay  = (int) ($data['amount'] ?? 0);
                                    $must = (int) ($data['actual_amount'] ?? 0);

                                    if ($pay < $must) {
                                        \Filament\Notifications\Notification::make()
                                            ->title('Amount kurang dari tagihan.')
                                            ->body('Jumlah yang dibayar harus ≥ Actual Amount.')
                                            ->danger()
                                            ->send();
                                        return; // batal insert
                                    }

                                    $methodForm = strtoupper((string) ($data['method'] ?? 'CASH'));
                                    $bankId     = isset($data['bank_id']) ? (int) $data['bank_id'] : null;

                                    // Wajib pilih bank utk CARD/TRANSFER (server-side guard)
                                    if (in_array($methodForm, ['CARD', 'TRANSFER'], true) && empty($bankId)) {
                                        \Filament\Notifications\Notification::make()
                                            ->title('Bank belum dipilih.')
                                            ->body('Pilih bank untuk metode CARD/TRANSFER.')
                                            ->warning()
                                            ->send();
                                        return;
                                    }

                                    // (Opsional) Pastikan bank milik hotel yang sama
                                    if ($bankId) {
                                        $isSameHotel = \App\Models\Bank::whereKey($bankId)
                                            ->where('hotel_id', $record->hotel_id)
                                            ->exists();

                                        if (! $isSameHotel) {
                                            \Filament\Notifications\Notification::make()
                                                ->title('Bank tidak valid.')
                                                ->body('Akun bank yang dipilih tidak sesuai dengan hotel aktif.')
                                                ->danger()
                                                ->send();
                                            return;
                                        }
                                    }

                                    $methodForLedger = match ($methodForm) {
                                        'CASH'     => 'cash',
                                        'CARD'     => 'edc',
                                        'TRANSFER' => 'transfer',
                                        default    => 'other',
                                    };


                                    DB::transaction(function () use ($data, $record, $methodForLedger, $bankId) {

                                        if (filled($record->actual_checkout)) {
                                            \Filament\Notifications\Notification::make()
                                                ->title('Guest ini sudah checkout.')
                                                ->warning()
                                                ->send();
                                            return;
                                        }

                                        $res = $record->reservation;
                                        if (! $res) {
                                            \Filament\Notifications\Notification::make()
                                                ->title('Reservation tidak ditemukan.')
                                                ->warning()
                                                ->send();
                                            return;
                                        }

                                        $payment = Payment::create([
                                            'hotel_id'             => $res->hotel_id,
                                            'reservation_id'       => $res->id,
                                            'reservation_guest_id' => $record->id,
                                            'bank_id' => $bankId,
                                            // amount = uang yang dibayar guest
                                            'amount'               => (int) $data['amount'],
                                            // actual_amount = persis "Amount to pay now" saat modal dibuka
                                            'actual_amount'        => (int) $data['actual_amount'],
                                            'method'               => (string) $data['method'],
                                            'payment_date'         => now(),
                                            // perhatikan: di model fillable kamu pakai 'notes', bukan 'note'
                                            'notes'                => (string) ($data['note'] ?? ''),
                                            'created_by'           => \Illuminate\Support\Facades\Auth::id(),
                                        ]);

                                        // --- Hitung angka dasar untuk deskripsi & tanggal ---
                                        $entryDate   = now()->toDateString();
                                        $description = 'Room Checkout #' . ($res->reservation_no ?? $res->id);
                                        $amountIn    = (int) ($data['amount'] ?? 0);

                                        // --- Hitung kas masuk net & kembalian ---
                                        //   $data['amount']         = uang yang diterima kasir
                                        //   $data['actual_amount']  = Amount to pay now (tagihan saat modal dibuka)
                                        $paid   = (int) ($data['amount'] ?? 0);
                                        $actual = (int) ($data['actual_amount'] ?? 0);
                                        $change = max(0, $paid - $actual);     // kembalian jika overpay
                                        $amountInNet = min($paid, $actual);    // kas masuk bersih untuk menutup tagihan

                                        // --- Post langsung ke ledger (tanpa event): ---
                                        // CASH (atau tanpa bank) => masuk akun kas (AccountLedger)
                                        if ($methodForLedger === 'cash' || empty($bankId)) {

                                            // (1) Kas masuk bersih (sampai sebesar tagihan)
                                            AccountLedger::create([
                                                'hotel_id'        => (int) $res->hotel_id,
                                                'ledger_type'     => 'room',             // sesuaikan jika perlu
                                                'reference_table' => 'payments',
                                                'reference_id'    => (int) $payment->id,
                                                'account_code'    => 'CASH_ON_HAND',     // opsional: kode akun kas
                                                'method'          => 'cash',

                                                'debit'           => $amountInNet,       // uang masuk bersih
                                                'credit'          => 0,

                                                'date'            => $entryDate,
                                                'description'     => $description . ' (receipt)',

                                                'is_posted'       => true,
                                                'posted_at'       => now(),
                                                'posted_by'       => Auth::id(),
                                            ]);

                                            // (2) Jika ada kembalian, catat kas keluar
                                            if ($change > 0) {
                                                AccountLedger::create([
                                                    'hotel_id'        => (int) $res->hotel_id,
                                                    'ledger_type'     => 'room',
                                                    'reference_table' => 'payments',
                                                    'reference_id'    => (int) $payment->id,
                                                    'account_code'    => 'CASH_ON_HAND',
                                                    'method'          => 'cash',

                                                    'debit'           => 0,
                                                    'credit'          => $change,        // kas keluar (kembalian)

                                                    'date'            => $entryDate,
                                                    'description'     => $description . ' (change returned)',

                                                    'is_posted'       => true,
                                                    'posted_at'       => now(),
                                                    'posted_by'       => Auth::id(),
                                                ]);
                                            }
                                        } else {
                                            // Metode CARD/TRANSFER => BankLedger

                                            // (1) Bank masuk bersih (sampai sebesar tagihan)
                                            BankLedger::create([
                                                'hotel_id'        => (int) $res->hotel_id,
                                                'bank_id'         => (int) $bankId,
                                                'deposit'         => $amountInNet,      // uang masuk bersih
                                                'withdraw'        => 0,
                                                'date'            => $entryDate,
                                                'description'     => $description . ' (receipt)',
                                                'method'          => $methodForLedger,  // 'edc' / 'transfer'
                                                'ledger_type'     => 'room',
                                                'reference_table' => 'payments',
                                                'reference_id'    => (int) $payment->id,
                                                'is_posted'       => true,
                                                'posted_at'       => now(),
                                                'posted_by'       => Auth::id(),
                                            ]);

                                            // (2) (Jarang) jika ada kembalian via bank (refund)
                                            if ($change > 0) {
                                                BankLedger::create([
                                                    'hotel_id'        => (int) $res->hotel_id,
                                                    'bank_id'         => (int) $bankId,
                                                    'deposit'         => 0,
                                                    'withdraw'        => $change,       // bank keluar (refund/kembalian)
                                                    'date'            => $entryDate,
                                                    'description'     => $description . ' (refund/change)',
                                                    'method'          => $methodForLedger,
                                                    'ledger_type'     => 'room',
                                                    'reference_table' => 'payments',
                                                    'reference_id'    => (int) $payment->id,
                                                    'is_posted'       => true,
                                                    'posted_at'       => now(),
                                                    'posted_by'       => Auth::id(),
                                                ]);
                                            }
                                        }


                                        $now = now();
                                        $resFresh = $res->fresh();

                                        $openGuests = $resFresh->reservationGuests()->whereNull('actual_checkout')->get();
                                        foreach ($openGuests as $g) {
                                            // checkout-kan SELALU untuk guest pemicu ($record),
                                            // dan checkout-kan guest lain hanya jika SUDAH ada payment.
                                            $hasPayment = \App\Models\Payment::where('reservation_guest_id', $g->id)->exists();
                                            if (! $hasPayment && $g->id !== $record->id) {
                                                continue;
                                            }

                                            $g->forceFill([
                                                'actual_checkout' => $now,
                                                'bill_closed_at'  => $now,
                                            ])->save();

                                            // ===== Mark all minibar receipts for this guest as PAID on checkout =====
                                            $mr = \App\Models\MinibarReceipt::query()
                                                ->where('reservation_guest_id', $g->id);

                                            $update = [];
                                            if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'is_paid')) {
                                                $update['is_paid'] = true;
                                            }
                                            if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'status')) {
                                                $update['status'] = 'PAID';
                                            }
                                            if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'paid_at')) {
                                                $update['paid_at'] = $now;
                                            }
                                            if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'paid_by')) {
                                                $update['paid_by'] = \Illuminate\Support\Facades\Auth::id();
                                            }
                                            if (\Illuminate\Support\Facades\Schema::hasColumn('minibar_receipts', 'updated_by')) {
                                                $update['updated_by'] = \Illuminate\Support\Facades\Auth::id();
                                            }
                                            if (! empty($update)) {
                                                $mr->update($update);
                                            }

                                            if ($g->room_id) {
                                                \App\Models\Room::whereKey($g->room_id)->update([
                                                    'status'            => \App\Models\Room::ST_VD,
                                                    'status_changed_at' => $now,
                                                ]);
                                            }
                                        }

                                        if ($resFresh->reservationGuests()->whereNull('actual_checkout')->count() === 0 && ! $resFresh->checkout_date) {
                                            $resFresh->checkout_date = $now;
                                            $resFresh->save();
                                        }

                                        \Filament\Notifications\Notification::make()
                                            ->title('Payment tersimpan & semua guest sudah checkout.')
                                            ->success()
                                            ->send();
                                    });

                                    $printUrl = route('reservation-guests.bill', $record) . '?mode=all';
                                    $listUrl  = url('/admin/reservation-guest-check-outs'); // atau ReservationGuestCheckOutResource::getUrl('index')

                                    $jsPrint  = json_encode($printUrl);
                                    $jsList   = json_encode($listUrl);

                                    $livewire->js(<<<JS
                                    (() => {
                                    // buka print di tab baru
                                    const a = document.createElement('a');
                                    a.href = {$jsPrint};
                                    a.target = '_blank';
                                    a.rel = 'noopener,noreferrer';
                                    a.style.display = 'none';
                                    document.body.appendChild(a);
                                    a.click();
                                    document.body.removeChild(a);

                                    // redirect halaman sekarang ke list
                                    window.location.href = {$jsList};
                                    })();
                                    JS);

                                    return;
                                }),
                        ])->columns(1)->columnSpan(3)->alignment('center'),

                    ]),
                ])
                ->columnSpanFull(),

        ]);
    }


    /**
     * Hitung detail breakdown untuk modal folio & print
     */
    private static function buildBreakdown(ReservationGuest $rg): array
    {
        $calc = ReservationMath::guestBill($rg, ['tz' => 'Asia/Makassar']);

        $tz    = 'Asia/Makassar';
        $start = $rg->actual_checkin ?? $rg->expected_checkin;
        $end   = $rg->actual_checkout ?: \Illuminate\Support\Carbon::now($tz);

        $totalAll      = 0;
        $totalChecked  = 0;
        $checkedItems  = []; // <-- detail siapa & berapa

        if ($rg->reservation) {
            $allGuests = $rg->reservation->reservationGuests()->orderBy('id')->get();

            foreach ($allGuests as $g) {
                $calcG  = \App\Support\ReservationMath::guestBill($g, ['tz' => 'Asia/Makassar']);
                $grandG = (int) ($calcG['grand'] ?? 0);

                $totalAll += $grandG;

                if (filled($g->actual_checkout)) {
                    $totalChecked += $grandG;
                    $checkedItems[] = [
                        'guest_id'   => $g->id,
                        'guest_name' => $g->guest?->name ?: ('RG#' . $g->id),
                        'amount'     => $grandG,
                    ];
                }
            }
        }

        $openDue = max(0, $totalAll - $totalChecked);

        return [
            'reservation_total_all'     => (int) $totalAll,
            'reservation_total_checked' => (int) $totalChecked,
            'reservation_open_due'      => (int) $openDue,
            'checked_items'             => $checkedItems, // <-- baru
            'rg'                => $rg,
            'nights'            => $calc['nights'],
            'rate_after_disc'   => (int) $calc['room_after_disc'],
            'charge'            => (int) $calc['charge'],
            'extra_bed'         => (int) $calc['extra'],
            'late_penalty'      => (int) $calc['penalty'],
            'tax_percent'       => (float) $calc['tax_percent'],
            'tax_rp'            => (int) $calc['tax_rp'],
            'grand_total'       => (int) $calc['grand'],
            'deposit'           => (int) $calc['deposit'],

            'arrive_at'         => $start ? \Illuminate\Support\Carbon::parse($start)->format('d/m/Y H:i') : '-',
            'depart_at'         => $end   ? \Illuminate\Support\Carbon::parse($end)->format('d/m/Y H:i')   : '-',
            'guest_name'        => $rg->guest?->name,
            'room_no'           => $rg->room?->room_no,
        ];
    }
}
