<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            if (! Schema::hasColumn('reservations', 'reservation_no')) {
                $table->string('reservation_no', 20)->nullable()->unique()->after('id');
            }
            if (! Schema::hasColumn('reservations', 'option')) {
                $table->string('option', 20)->nullable()->after('reservation_no'); // WALKIN / GROUP / etc (sesuaikan)
            }
            if (! Schema::hasColumn('reservations', 'method')) {
                $table->string('method', 20)->nullable()->after('option'); // PHONE / WA/SMS / EMAIL / ...
            }
            if (! Schema::hasColumn('reservations', 'status')) {
                $table->string('status', 20)->nullable()->after('method'); // CONFIRM / TENTATIVE / CANCELLED
            }
            if (! Schema::hasColumn('reservations', 'expected_arrival')) {
                $table->dateTime('expected_arrival')->nullable()->after('status');
            }
            if (! Schema::hasColumn('reservations', 'expected_departure')) {
                $table->dateTime('expected_departure')->nullable()->after('expected_arrival');
            }
            if (! Schema::hasColumn('reservations', 'deposit')) {
                $table->decimal('deposit', 14, 2)->default(0)->after('expected_departure');
            }
            if (! Schema::hasColumn('reservations', 'reserved_title')) {
                $table->string('reserved_title', 10)->nullable()->after('guest_id'); // MR/MRS/MISS
            }
            if (! Schema::hasColumn('reservations', 'reserved_by')) {
                $table->string('reserved_by')->nullable()->after('reserved_title');
            }
            // Group details (opsional)
            foreach (
                [
                    'group_name' => 150,
                    'address' => 255,
                    'city' => 100,
                    'phone' => 50,
                    'handphone' => 50,
                    'fax' => 50,
                    'email' => 150,
                ] as $col => $len
            ) {
                if (! Schema::hasColumn('reservations', $col)) {
                    $table->string($col, $len)->nullable()->after('deposit');
                }
            }
            if (! Schema::hasColumn('reservations', 'long_remark')) {
                $table->text('long_remark')->nullable()->after('email');
            }

            // Soft delete kalau model pakai SoftDeletes
            if (! Schema::hasColumn('reservations', 'deleted_at')) {
                $table->softDeletes();
            }
        });
    }

    public function down(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            $drop = [
                'reservation_no',
                'option',
                'method',
                'status',
                'expected_arrival',
                'expected_departure',
                'deposit',
                'reserved_title',
                'reserved_by',
                'group_name',
                'address',
                'city',
                'phone',
                'handphone',
                'fax',
                'email',
                'long_remark',
            ];
            foreach ($drop as $c) {
                if (Schema::hasColumn('reservations', $c)) $table->dropColumn($c);
            }
            if (Schema::hasColumn('reservations', 'deleted_at')) $table->dropColumn('deleted_at');
        });
    }
};
