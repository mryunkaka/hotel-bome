<?php

declare(strict_types=1);

namespace App\Filament\Resources\FacilityBookings\Schemas;

use App\Models\Facility;
use Filament\Schemas\Schema;
use Illuminate\Support\Carbon;

use App\Models\FacilityBooking;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;

// Section yang kamu pakai berasal dari Schemas:
use Filament\Schemas\Components\Section;

// Utilities reaktif
use Illuminate\Database\Eloquent\Builder;
use Filament\Infolists\Components\TextEntry;

use Filament\Forms\Components\DateTimePicker;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;

final class FacilityBookingForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('Booking Info')
                ->columns(2)
                ->components([
                    Select::make('facility_id')
                        ->label('Facility')
                        ->relationship(
                            name: 'facility',
                            titleAttribute: 'name',
                            modifyQueryUsing: fn(Builder $q) => $q->where('is_active', true)->orderBy('name')
                        )
                        ->searchable()
                        ->preload()
                        ->required()
                        ->afterStateUpdated(function (?int $id, Set $set): void {
                            if (!$id) return;
                            /** @var Facility|null $f */
                            $f = Facility::find($id);
                            if ($f) {
                                $set('pricing_mode', $f->base_pricing_mode);
                                $set('unit_price', $f->base_price);
                            }
                        }),

                    TextInput::make('title')
                        ->label('Event / Notes (short)')
                        ->maxLength(150),

                    DateTimePicker::make('start_at')
                        ->seconds(false)
                        ->required()
                        ->reactive()
                        ->afterStateUpdated(fn(Get $get, Set $set) => self::autoQuantity($get, $set)),

                    DateTimePicker::make('end_at')
                        ->seconds(false)
                        ->required()
                        ->reactive()
                        ->afterStateUpdated(fn(Get $get, Set $set) => self::autoQuantity($get, $set)),

                    Textarea::make('notes')
                        ->rows(2)
                        ->columnSpanFull(),
                ]),

            Section::make('Pricing')
                ->columns(3)
                ->components([
                    Select::make('pricing_mode')
                        ->options([
                            FacilityBooking::PRICING_PER_HOUR => 'Per Hour',
                            FacilityBooking::PRICING_PER_DAY  => 'Per Day',
                            FacilityBooking::PRICING_FIXED    => 'Fixed',
                        ])
                        ->required()
                        ->reactive()
                        ->afterStateUpdated(function (Get $get, Set $set) {
                            self::autoQuantity($get, $set);
                            self::recalcTotals($get, $set);
                        }),

                    TextInput::make('unit_price')
                        ->numeric()
                        ->prefix('Rp')
                        ->required()
                        ->reactive()
                        ->afterStateUpdated(fn(Get $g, Set $s) => self::recalcTotals($g, $s)),

                    TextInput::make('quantity')
                        ->numeric()
                        ->minValue(0.5)
                        ->step('0.5')
                        ->required()
                        ->helperText('Hours/Days depending on pricing mode')
                        ->reactive()
                        ->afterStateUpdated(fn(Get $g, Set $s) => self::recalcTotals($g, $s)),

                    TextInput::make('discount_amount')
                        ->numeric()
                        ->prefix('Rp')
                        ->default(0)
                        ->reactive()
                        ->afterStateUpdated(fn(Get $g, Set $s) => self::recalcTotals($g, $s)),

                    Toggle::make('include_catering')
                        ->inline(false)
                        ->default(false)
                        ->helperText('Detail catering dikelola di Relation “Catering”.'),

                    // ⬇️ ganti Placeholder -> TextEntry agar tidak deprecated
                    TextEntry::make('catering_total_amount_view')
                        ->label('Catering Amount (summary)')
                        ->formatStateUsing(fn(Get $get) => 'Rp ' . number_format((float) ($get('catering_total_amount') ?? 0), 0, ',', '.')),

                    TextInput::make('tax_amount')
                        ->numeric()
                        ->prefix('Rp')
                        ->default(0)
                        ->reactive()
                        ->afterStateUpdated(fn(Get $g, Set $s) => self::recalcTotals($g, $s)),

                    TextInput::make('subtotal_amount')
                        ->numeric()
                        ->prefix('Rp')
                        ->readOnly()
                        ->dehydrated(true),

                    TextInput::make('total_amount')
                        ->numeric()
                        ->prefix('Rp')
                        ->readOnly()
                        ->dehydrated(true),
                ]),

            Section::make('Status & Audit')
                ->columns(3)
                ->components([
                    Select::make('status')
                        ->options([
                            FacilityBooking::STATUS_DRAFT     => 'DRAFT',
                            FacilityBooking::STATUS_CONFIRM   => 'CONFIRM',
                            FacilityBooking::STATUS_PAID      => 'PAID',
                            FacilityBooking::STATUS_COMPLETED => 'COMPLETED',
                            FacilityBooking::STATUS_CANCELLED => 'CANCELLED',
                        ])
                        ->default(FacilityBooking::STATUS_DRAFT)
                        ->required(),

                    Toggle::make('is_blocked')
                        ->label('Schedule Blocked')
                        ->disabled()
                        ->default(false),

                    Hidden::make('hotel_id')->dehydrated(true),
                    Hidden::make('catering_total_amount')->default(0)->dehydrated(true),
                    Hidden::make('catering_total_pax')->default(0)->dehydrated(true),
                ]),
        ]);
    }

    /** ===== Helpers ===== */
    private static function autoQuantity(Get $get, Set $set): void
    {
        $mode = $get('pricing_mode') ?: FacilityBooking::PRICING_PER_HOUR;
        $s = $get('start_at');
        $e = $get('end_at');
        if (!$s || !$e) return;

        $start = Carbon::parse($s);
        $end   = Carbon::parse($e);
        if ($end->lessThanOrEqualTo($start)) return;

        if ($mode === FacilityBooking::PRICING_PER_DAY) {
            $hours = $start->floatDiffInRealHours($end);
            $days  = max(1, (int) ceil($hours / 24));
            $set('quantity', $days);
        } elseif ($mode === FacilityBooking::PRICING_PER_HOUR) {
            $hours = max(1, round($start->floatDiffInRealHours($end), 1));
            $set('quantity', $hours);
        } else {
            $set('quantity', 1);
        }

        self::recalcTotals($get, $set);
    }

    private static function recalcTotals(Get $get, Set $set): void
    {
        $unit = (float) ($get('unit_price') ?? 0);
        $qty  = (float) ($get('quantity') ?? 0);
        $disc = (float) ($get('discount_amount') ?? 0);
        $cat  = (float) ($get('catering_total_amount') ?? 0);
        $tax  = (float) ($get('tax_amount') ?? 0);

        $base     = max(0, $unit * $qty);
        $subtotal = max(0, $base - $disc);
        $total    = $subtotal + $cat + $tax;

        $set('subtotal_amount', $subtotal);
        $set('total_amount', $total);
    }
}
