<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GuestSeeder extends Seeder
{
    public function run(): void
    {
        $guests = [
            ['name' => 'Andi Wijaya', 'phone' => '081234567890', 'email' => 'andi@example.com'],
            ['name' => 'Budi Santoso', 'phone' => '081298765432', 'email' => 'budi@example.com'],
            ['name' => 'Citra Ayu',    'phone' => '081377788899', 'email' => 'citra@example.com'],
            ['name' => 'Dewi Lestari', 'phone' => '081212341234', 'email' => 'dewi@example.com'],
        ];

        foreach ($guests as $g) {
            DB::table('guests')->updateOrInsert(
                ['email' => $g['email']],
                [
                    'name'       => $g['name'],
                    'phone'      => $g['phone'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }
    }
}
