<?php

namespace App\Filament\Resources\MinibarDailyClosings\Pages;

use App\Filament\Resources\MinibarDailyClosings\MinibarDailyClosingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMinibarDailyClosing extends CreateRecord
{
    protected static string $resource = MinibarDailyClosingResource::class;
}
