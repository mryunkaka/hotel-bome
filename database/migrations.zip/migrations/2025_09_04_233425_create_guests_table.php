<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('guests', function (Blueprint $table) {
            $table->id();

            // Scope per hotel
            $table->foreignId('hotel_id')->constrained()->cascadeOnDelete();

            // Data utama
            $table->string('name', 150);
            $table->string('email', 150)->nullable();
            $table->string('phone', 50)->nullable();
            $table->string('address', 255)->nullable();

            // Identitas
            $table->string('nid_no', 100)->nullable();              // NIK / NID No
            $table->string('nid_file_path', 255)->nullable();       // path file NID
            $table->string('passport_no', 100)->nullable();
            $table->string('passport_file_path', 255)->nullable();  // path file paspor

            // Keluarga
            $table->string('father', 150)->nullable();
            $table->string('mother', 150)->nullable();
            $table->string('spouse', 150)->nullable();

            // Foto
            $table->string('photo_path', 255)->nullable();

            $table->timestamps();
            $table->softDeletes();

            // Indexes & unique (unik per hotel; kolom nullable boleh lebih dari satu NULL di MySQL)
            $table->index(['hotel_id', 'name']);
            $table->index('email');
            $table->unique(['hotel_id', 'nid_no']);
            $table->unique(['hotel_id', 'passport_no']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('guests');
    }
};
