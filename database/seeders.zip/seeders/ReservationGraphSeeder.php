<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ReservationGraphSeeder extends Seeder
{
    public function run(): void
    {
        $hotelId = \App\Models\Hotel::where('name', 'Hotel Bome')->value('id')
            ?? \App\Models\Hotel::orderBy('id')->value('id');

        // creator
        $resepsionisId = \App\Models\User::where('hotel_id', $hotelId)
            ->whereHas('roles', fn($q) => $q->where('name', 'resepsionis'))
            ->value('id');

        $supervisorId = \App\Models\User::where('hotel_id', $hotelId)
            ->whereHas('roles', fn($q) => $q->where('name', 'supervisor'))
            ->value('id');

        $superAdminId = \App\Models\User::whereNull('hotel_id')
            ->whereHas('roles', fn($q) => $q->where('name', 'super admin'))
            ->value('id');

        $createdBy = $resepsionisId ?? $supervisorId ?? $superAdminId;

        $idTax = DB::table('tax_settings')->where('is_active', true)->orderBy('id')->value('id');

        // ambil guests
        $guestIds = DB::table('guests')->orderBy('id')->pluck('id')->take(4)->values()->all();

        // ambil beberapa rooms
        $room101 = DB::table('rooms')->where('hotel_id', $hotelId)->where('room_no', '101')->value('id');
        $room102 = DB::table('rooms')->where('hotel_id', $hotelId)->where('room_no', '102')->value('id');
        $room108 = DB::table('rooms')->where('hotel_id', $hotelId)->where('room_no', '108')->value('id');

        // === RESERVATION A: belum check-in ===
        $resAId = DB::table('reservations')->insertGetId([
            'hotel_id'           => $hotelId,
            'group_id'           => null,
            'guest_id'           => $guestIds[0] ?? null,
            'reservation_no'     => 'BOME-A-' . now()->format('YmdHis'),
            'option_reservation' => 'reservation',
            'method'             => 'WEB',
            'status'             => 'CONFIRM',
            'expected_arrival'   => now()->addDay()->startOfDay()->addHours(14),
            'expected_departure' => now()->addDays(2)->startOfDay()->addHours(12),
            'checkin_date'       => null,
            'checkout_date'      => null,
            'deposit_type'       => 'NONE',
            'deposit'            => 0,
            'deposit_room'       => 0,
            'deposit_card'       => 0,
            'id_tax'             => $idTax,
            'reserved_by'        => 'Andi',
            'reserved_by_type'   => 'GUEST',
            'entry_date'         => now(),
            'num_guests'         => 1,
            'created_by'         => $createdBy,
            'created_at'         => now(),
            'updated_at'         => now(),
        ]);

        DB::table('reservation_guests')->insert([
            'hotel_id'         => $hotelId,
            'reservation_id'   => $resAId,
            'guest_id'         => $guestIds[0] ?? null,
            'room_id'          => $room101,
            'expected_checkin' => now()->addDay()->startOfDay()->addHours(14),
            'expected_checkout' => now()->addDays(2)->startOfDay()->addHours(12),
            'actual_checkin'   => null,
            'actual_checkout'  => null,
            'service'          => 0,
            'charge'           => 0,
            'room_rate'        => 350_000,
            'extra_bed'        => 0,
            'note'             => 'Belum CI',
            'bill_no'          => null,
            'created_by'       => $createdBy,
            'created_at'       => now(),
            'updated_at'       => now(),
        ]);

        // === RESERVATION B: sudah check-out (payment dibuat) ===
        $resBId = DB::table('reservations')->insertGetId([
            'hotel_id'           => $hotelId,
            'group_id'           => null,
            'guest_id'           => $guestIds[1] ?? null,
            'reservation_no'     => 'BOME-B-' . now()->format('YmdHis'),
            'option_reservation' => 'walkin',
            'method'             => 'FRONTDESK',
            'status'             => 'CONFIRM',
            'expected_arrival'   => now()->subDay()->startOfDay()->addHours(14),
            'expected_departure' => now()->startOfDay()->addHours(12),
            'checkin_date'       => now()->subDay()->startOfDay()->addHours(14),
            'checkout_date'      => now(),
            'deposit_type'       => 'NONE',
            'deposit'            => 0,
            'deposit_room'       => 0,
            'deposit_card'       => 0,
            'id_tax'             => $idTax,
            'reserved_by'        => 'Budi',
            'reserved_by_type'   => 'GUEST',
            'entry_date'         => now()->subDay(),
            'num_guests'         => 1,
            'created_by'         => $createdBy,
            'created_at'         => now(),
            'updated_at'         => now(),
        ]);

        $rgBId = DB::table('reservation_guests')->insertGetId([
            'hotel_id'         => $hotelId,
            'reservation_id'   => $resBId,
            'guest_id'         => $guestIds[1] ?? null,
            'room_id'          => $room108,
            'expected_checkin' => now()->subDay()->startOfDay()->addHours(14),
            'expected_checkout' => now()->startOfDay()->addHours(12),
            'actual_checkin'   => now()->subDay()->startOfDay()->addHours(14),
            'actual_checkout'  => now()->startOfDay()->addHours(11),
            'service'          => 0,
            'charge'           => 0,
            'room_rate'        => 400_000,
            'extra_bed'        => 0,
            'note'             => 'Sudah CO',
            'bill_no'          => 'BILL-' . $resBId,
            'created_by'       => $createdBy,
            'created_at'       => now(),
            'updated_at'       => now(),
        ]);

        // Payment utk B (sudah CO)
        DB::table('payments')->insert([
            'reservation_id'       => $resBId,
            'hotel_id'             => $hotelId,
            'reservation_guest_id' => $rgBId,
            'amount'               => 440000,             // 400k + 10% pajak
            'actual_amount'        => 440000,
            'deposit_used'         => 0,
            'is_deposit_refund'    => false,
            'deposit_refund_note'  => null,
            'method'               => 'CASH',
            'payment_date'         => now(),
            'reference_no'         => 'PAY-' . $rgBId,
            'notes'                => 'Auto seed payment',
            'created_by'           => $createdBy,
            'created_at'           => now(),
            'updated_at'           => now(),
        ]);

        // === RESERVATION C: sudah CI, belum CO ===
        $resCId = DB::table('reservations')->insertGetId([
            'hotel_id'           => $hotelId,
            'guest_id'           => $guestIds[2] ?? null,
            'reservation_no'     => 'BOME-C-' . now()->format('YmdHis'),
            'option_reservation' => 'walkin',
            'method'             => 'FRONTDESK',
            'status'             => 'CONFIRM',
            'expected_arrival'   => now()->startOfDay()->addHours(14),
            'expected_departure' => now()->addDay()->startOfDay()->addHours(12),
            'checkin_date'       => now()->startOfDay()->addHours(14),
            'checkout_date'      => null,
            'deposit_type'       => 'NONE',
            'deposit'            => 0,
            'deposit_room'       => 0,
            'deposit_card'       => 0,
            'id_tax'             => $idTax,
            'reserved_by'        => 'Citra',
            'reserved_by_type'   => 'GUEST',
            'entry_date'         => now(),
            'num_guests'         => 1,
            'created_by'         => $createdBy,
            'created_at'         => now(),
            'updated_at'         => now(),
        ]);

        DB::table('reservation_guests')->insert([
            'hotel_id'         => $hotelId,
            'reservation_id'   => $resCId,
            'guest_id'         => $guestIds[2] ?? null,
            'room_id'          => $room102,
            'expected_checkin' => now()->startOfDay()->addHours(14),
            'expected_checkout' => now()->addDay()->startOfDay()->addHours(12),
            'actual_checkin'   => now()->startOfDay()->addHours(14),
            'actual_checkout'  => null,
            'service'          => 0,
            'charge'           => 0,
            'room_rate'        => 350_000,
            'extra_bed'        => 0,
            'note'             => 'In-house',
            'bill_no'          => null,
            'created_by'       => $createdBy,
            'created_at'       => now(),
            'updated_at'       => now(),
        ]);
    }
}
