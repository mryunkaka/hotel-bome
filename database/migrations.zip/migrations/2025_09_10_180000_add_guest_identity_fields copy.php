<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('guests', function (Blueprint $table) {
            if (!Schema::hasColumn('guests', 'guest_type')) {
                $table->string('guest_type', 12)->nullable()->after('salutation'); // DOMESTIC / FOREIGNER
            }
            if (!Schema::hasColumn('guests', 'id_type')) {
                $table->string('id_type', 20)->nullable()->after('guest_type'); // KTP / PASSPORT / OTHER
            }
        });
    }
    public function down(): void
    {
        Schema::table('guests', function (Blueprint $table) {
            if (Schema::hasColumn('guests', 'guest_type')) $table->dropColumn('guest_type');
            if (Schema::hasColumn('guests', 'id_type')) $table->dropColumn('id_type');
        });
    }
};
