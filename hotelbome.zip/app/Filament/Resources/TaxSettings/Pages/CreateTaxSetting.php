<?php

namespace App\Filament\Resources\TaxSettings\Pages;

use App\Filament\Resources\TaxSettings\TaxSettingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateTaxSetting extends CreateRecord
{
    protected static string $resource = TaxSettingResource::class;
}
