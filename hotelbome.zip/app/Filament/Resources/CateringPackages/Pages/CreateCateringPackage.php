<?php

namespace App\Filament\Resources\CateringPackages\Pages;

use App\Filament\Resources\CateringPackages\CateringPackageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCateringPackage extends CreateRecord
{
    protected static string $resource = CateringPackageResource::class;
}
