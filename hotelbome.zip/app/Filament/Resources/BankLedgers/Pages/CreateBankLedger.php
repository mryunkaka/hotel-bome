<?php

namespace App\Filament\Resources\BankLedgers\Pages;

use App\Filament\Resources\BankLedgers\BankLedgerResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBankLedger extends CreateRecord
{
    protected static string $resource = BankLedgerResource::class;
}
