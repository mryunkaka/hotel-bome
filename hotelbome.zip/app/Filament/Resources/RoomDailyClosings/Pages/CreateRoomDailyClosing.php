<?php

namespace App\Filament\Resources\RoomDailyClosings\Pages;

use App\Filament\Resources\RoomDailyClosings\RoomDailyClosingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateRoomDailyClosing extends CreateRecord
{
    protected static string $resource = RoomDailyClosingResource::class;
}
