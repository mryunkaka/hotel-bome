<?php

namespace App\Filament\Resources\Walkins\Pages;

use App\Filament\Resources\Walkins\WalkinResource;
use Filament\Resources\Pages\CreateRecord;

class CreateWalkin extends CreateRecord
{
    protected static string $resource = WalkinResource::class;
}
