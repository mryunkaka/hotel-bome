<?php

namespace App\Filament\Resources\MinibarVendors\Pages;

use App\Filament\Resources\MinibarVendors\MinibarVendorResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMinibarVendor extends CreateRecord
{
    protected static string $resource = MinibarVendorResource::class;
}
