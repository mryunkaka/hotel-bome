<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('reservations', function (Blueprint $table) {
            $table->id();

            $table->foreignId('hotel_id')->constrained()->cascadeOnDelete();
            $table->foreignId('room_id')->constrained('rooms')->cascadeOnDelete();
            $table->foreignId('guest_id')->constrained('guests')->cascadeOnDelete();

            $table->dateTime('checkin_date')->nullable();      // rencana check-in
            $table->dateTime('checkout_date')->nullable();     // rencana check-out
            $table->dateTime('actual_checkin')->nullable();    // real check-in
            $table->dateTime('actual_checkout')->nullable();   // real check-out

            $table->string('status')->default('booked'); // booked|checked_in|checked_out|no_show|cancelled
            $table->unsignedTinyInteger('num_guests')->default(1);
            $table->string('card_uid')->nullable(); // UID kartu RFID yang dipakai

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();

            $table->text('remarks')->nullable();

            $table->timestamps();

            $table->index(['hotel_id', 'status']);
            $table->index(['hotel_id', 'room_id']);
            $table->index(['hotel_id', 'guest_id']);
            $table->index(['hotel_id', 'card_uid']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reservations');
    }
};
