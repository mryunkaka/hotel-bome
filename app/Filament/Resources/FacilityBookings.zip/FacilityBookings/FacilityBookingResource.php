<?php

namespace App\Filament\Resources\FacilityBookings;

use App\Filament\Resources\FacilityBookings\Pages\CreateFacilityBooking;
use App\Filament\Resources\FacilityBookings\Pages\EditFacilityBooking;
use App\Filament\Resources\FacilityBookings\Pages\ListFacilityBookings;
use App\Filament\Resources\FacilityBookings\Schemas\FacilityBookingForm;
use App\Filament\Resources\FacilityBookings\Tables\FacilityBookingsTable;
use App\Models\FacilityBooking;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class FacilityBookingResource extends Resource
{
    protected static ?string $model = FacilityBooking::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    protected static ?string $recordTitleAttribute = 'facilitybooking';

    public static function form(Schema $schema): Schema
    {
        return FacilityBookingForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return FacilityBookingsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListFacilityBookings::route('/'),
            'create' => CreateFacilityBooking::route('/create'),
            'edit' => EditFacilityBooking::route('/{record}/edit'),
        ];
    }

    public static function getRecordRouteBindingEloquentQuery(): Builder
    {
        return parent::getRecordRouteBindingEloquentQuery()
            ->withoutGlobalScopes([
                SoftDeletingScope::class,
            ]);
    }
}
