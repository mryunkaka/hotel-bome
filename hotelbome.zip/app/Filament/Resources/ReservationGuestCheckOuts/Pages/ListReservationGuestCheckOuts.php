<?php

namespace App\Filament\Resources\ReservationGuestCheckOuts\Pages;

use App\Filament\Resources\ReservationGuestCheckOuts\ReservationGuestCheckOutResource;
use Filament\Resources\Pages\ListRecords;

class ListReservationGuestCheckOuts extends ListRecords
{
    protected static string $resource = ReservationGuestCheckOutResource::class;
}
