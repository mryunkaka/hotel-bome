<?php

namespace App\Filament\Resources\FacilityBookings\Pages;

use App\Filament\Resources\FacilityBookings\FacilityBookingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateFacilityBooking extends CreateRecord
{
    protected static string $resource = FacilityBookingResource::class;
}
