<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Guests: tambah sapaan (MR/MRS/MISS)
        Schema::table('guests', function (Blueprint $table) {
            if (! Schema::hasColumn('guests', 'salutation')) {
                $table->string('salutation', 10)->nullable()->index()->after('name'); // MR/MRS/MISS
            }
        });

        // Reservations: tambah method (Phone, WA/SMS, Email, Letter, Personal, OTA, Other)
        if (Schema::hasTable('reservations')) {
            Schema::table('reservations', function (Blueprint $table) {
                if (! Schema::hasColumn('reservations', 'method')) {
                    $table->string('method', 20)->nullable()->index()->after('status');
                }
            });
        }

        // Optional bila mau simpan "reserved_by" (nama orang yang pesan) di reservations
        if (Schema::hasTable('reservations')) {
            Schema::table('reservations', function (Blueprint $table) {
                if (! Schema::hasColumn('reservations', 'reserved_by')) {
                    $table->string('reserved_by')->nullable()->after('guest_id');
                }
            });
        }
    }

    public function down(): void
    {
        Schema::table('guests', function (Blueprint $table) {
            if (Schema::hasColumn('guests', 'salutation')) {
                $table->dropColumn('salutation');
            }
        });
        if (Schema::hasTable('reservations')) {
            Schema::table('reservations', function (Blueprint $table) {
                if (Schema::hasColumn('reservations', 'method')) {
                    $table->dropColumn('method');
                }
                if (Schema::hasColumn('reservations', 'reserved_by')) {
                    $table->dropColumn('reserved_by');
                }
            });
        }
    }
};
